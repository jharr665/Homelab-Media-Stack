# Placeholder for docs/SECURITY.md

This file is part of the homelab media stack repository.
